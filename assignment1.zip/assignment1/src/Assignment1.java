import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * The Assignment1 class analyzes ice sheet data for fracture points.
 */
public class Assignment1 {

    /**
     * The main method, entry point of the program.
     *
     * @param args Command-line arguments (not used in this program).
     */
    public static void main(String[] args) {

        analyzeIceSheets("src/ICESHEETS.TXT");
    }

    /**
     * Analyzes ice sheet data from a specified file and computes statistics.
     *
     * @param filePath The path to the input file containing ice sheet data.
     */
    public static void analyzeIceSheets(String filePath) {
        try {
            Scanner scanner = new Scanner(new File(filePath));

            int numSheets = scanner.nextInt();
            scanner.nextLine();

            int maxFracturePoints = Integer.MIN_VALUE;
            int sheetWithMaxFracturePoints = -1;
            int totalFracturePoints = 0;
            int totalFracturePointsMayCrack = 0;

            for (int sheetNumber = 1; sheetNumber <= numSheets; sheetNumber++) {
                int numRows = scanner.nextInt();
                int numCols = scanner.nextInt();
                scanner.nextLine();

                int[][] sheet = new int[numRows][numCols];
                int fracturePoints = 0;
                int crackPoints = 0;

                for (int row = 0; row < numRows; row++) {
                    for (int col = 0; col < numCols; col++) {
                        sheet[row][col] = scanner.nextInt();
                        if (sheet[row][col] <= 200 && sheet[row][col] % 50 == 0) {
                            fracturePoints++;
                            if (isCrackPoint(sheet, row, col)) {
                                crackPoints++;
                                System.out.println("Sheet #" + sheetNumber + ": Crack Point at (" + row + ", " + col + ")");
                            }
                        }
                    }
                }

                totalFracturePoints += fracturePoints;
                totalFracturePointsMayCrack += crackPoints;

                if (fracturePoints > maxFracturePoints) {
                    maxFracturePoints = fracturePoints;
                    sheetWithMaxFracturePoints = sheetNumber;
                }

                scanner.nextLine();
            }

            // Print the results for Part B
            System.out.println("Number of fracture points on the sheet that may crack: " + totalFracturePointsMayCrack);
            double fractionOfCracks = (double) totalFracturePointsMayCrack / totalFracturePoints;
            System.out.printf("Fraction of fracture points that are crack points: %.3f%n", fractionOfCracks);

            // Print the results for Part A
            System.out.println("Part A - Potential Fracture Points:");
            System.out.println("Total number of potential fracture points: " + totalFracturePoints);
            System.out.println("Sheet with the most fracture points: Sheet " + sheetWithMaxFracturePoints);
            System.out.println("Number of fracture points on the sheet with the most fracture points: " + maxFracturePoints);

            scanner.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + e.getMessage());
        }
    }

    /**
     * Determines if a point on the ice sheet is a crack point.
     *
     * @param sheet The 2D array representing the ice sheet.
     * @param row   The row index of the point.
     * @param col   The column index of the point.
     * @return True if the point is a crack point, otherwise false.
     */
    public static boolean isCrackPoint(int[][] sheet, int row, int col) {
        int numRows = sheet.length;
        int numCols = sheet[0].length;

        // Define adjacent positions
        int[][] directions = {
                {-1, -1}, {-1, 0}, {-1, 1},
                {0, -1},           {0, 1},
                {1, -1}, {1, 0}, {1, 1}
        };

        int fracturePointValue = sheet[row][col];

        for (int[] dir : directions) {
            int newRow = row + dir[0];
            int newCol = col + dir[1];

            if (newRow >= 0 && newRow < numRows && newCol >= 0 && newCol < numCols) {
                int adjacentPoint = sheet[newRow][newCol];
                if (adjacentPoint % 10 == 0 && fracturePointValue % 10 == 0) {
                    return true;
                }
            }
        }

        return false;
    }
}

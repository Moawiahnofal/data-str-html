/**
COMP-10205 - Starting code for Assignment # 2
**/
import java.util.Arrays;
/**
========================================
COMP-10205 – Data Structure and Algorithms
Assignment#2 - Comments Section for Part 3
========================================

a. List in order (fastest to slowest) your selection of algorithm to use when the array to be sorted contains 20 elements. Base this on your results.
- Expected Order for small datasets like 20 elements:
  1. Insertion Sort (cSort)
  2. Selection Sort (bSort)
  3. Bubble Sort (eSort)
  4. QuickSort (aSort)
  5. MergeSort (dSort)
  6. ShellSort (fSort)
  7. Radix Sort (gSort)



b. List in order (fastest to slowest) your selection of algorithm to use when the array to be sorted contains 50000 elements.
- Expected Order for larger datasets like 50,000 elements:
  1. QuickSort (aSort)
  2. MergeSort (dSort)
  3. Radix Sort (gSort)
  4. ShellSort (fSort)
  5. Insertion Sort (cSort)
  6. Selection Sort (bSort)
  7. Bubble Sort (eSort)


c. At 50000 elements which sort has the lowest basic instruction set time? Does this impact your selection of the fastest algorithm? Why?
-(dSort) and QuickSort (aSort) have the lowest basic
instruction set time.
This does impact the selection of the fastest algorithm as fewer instructions generally lead to faster
 execution, especially for larger data sets.

d. In a table provide the following information for each algorithm:
Sort Algorithm Identification
==========================================================
Sort Sort   Algorithm                 Big O                  Big o
Algorithm   Name                      (time)                (space)
-----------------------------------------------------------
aSort     QuickSort                  O(n log n)             O(log n)
bSort     Selection Sort             O(n^2)                 O(1)
cSort     Insertion Sort             O(n^2)                 O(1)
dSort     MergeSort                  O(n log n)             O(n)
eSort     Bubble Sort                O(n^2)                 O(1)
fSort     ShellSort                  O(n log n)             O(1)
gSort     Radix Sort                 O(nk)                  O(n + k)

**/

/**
 * interface used so we can pass method references to Perfromance method
 *
 **/
/**
 * All methods are static to the class - functional style
 *
 * @author moawiah.nofal
 **/
public class assignment2 {
    static long qSortCompares = 0; // Left in for comparison purposes only
    /**
     * The swap method swaps the contents of two elements in an int array.
     *
     * @param array where elements are to be swapped.
     * @param a The subscript of the first element.
     * @param b The subscript of the second element.
     */
    private static void swap(int[] array, int a, int b) {
        int temp;
        temp = array[a];
        array[a] = array[b];
        array[b] = temp;
    }
    //------------------- e Sort -------------------------
    public static long eSort(int[] array) {
        int lastPos; // Position of last element to compare
        int index;// Index of an element to compare

// The outer loop positions lastPos at the last element
// to compare during each pass through the array. Initially
// lastPos is the index of the last element in the array.
// During each iteration, it is decreased by one.
        for (lastPos = array.length - 1; lastPos >= 0; lastPos--) {
// The inner loop steps through the array, comparing
// each element with its neighbor. All of the elements
// from index 0 thrugh lastPos are involved in the
// comparison. If two elements are out of order, they
// are swapped.
            for (index = 0; index <= lastPos - 1; index++) {

                qSortCompares++;
                // Compare an element with its neighbor.
                if (array[index] > array[index + 1]) {
                    // Swap the two elements.
                    swap(array, index, index + 1);
                }

            }

            }

        return qSortCompares;
    }
    /**
     *------------- cSort -------------------------------------------------
     *
     */
    public static long cSort(int[] array) {
        int unsortedValue; // The first unsorted value
        int scan; // Used to scan the array

// The outer loop steps the index variable through
// each subscript in the array, starting at 1. The portion of
// the array containing element 0 by itself is already sorted.
        for (int index = 1; index < array.length; index++) {

// The first element outside the sorted portion is
// array[index]. Store the value of this element
// in unsortedValue.
            unsortedValue = array[index];
// Start scan at the subscript of the first element
// outside the sorted part.
            scan = index;
// Move the first element in the still unsorted part
// into its proper position within the sorted part.
            while (scan > 0 && array[scan - 1] > unsortedValue) {
                array[scan] = array[scan - 1];
                scan--;
                qSortCompares++;
            }
// Insert the unsorted value in its proper position
// within the sorted subset.
            array[scan] = unsortedValue;
        }
        return qSortCompares;
    }
    /**
     *------------------- b Sort ---------------------------------------------
     *
     */
    public static long bSort(int[] array) {
        int startScan; // Starting position of the scan
        int index; // To hold a subscript value
        int minIndex; // Element with smallest value in the scan
        int minValue; // The smallest value found in the scan

// The outer loop iterates once for each element in the
// array. The startScan variable marks the position where
// the scan should begin.
        for (startScan = 0; startScan < (array.length - 1); startScan++) {
// Assume the first element in the scannable area
// is the smallest value.
            minIndex = startScan;
            minValue = array[startScan];
// Scan the array, starting at the 2nd element in
// the scannable area. We are looking for the smallest
// value in the scannable area.
            for (index = startScan + 1; index < array.length; index++) {
                qSortCompares++;
                if (array[index] < minValue) {
                    minValue = array[index];
                    minIndex = index;

                }
            }
// Swap the element with the smallest value
// with the first element in the scannable area.
            array[minIndex] = array[startScan];
            array[startScan] = minValue;
        }
        return qSortCompares;
    }
    /**
     * -------------------------- f Sort --------------------------------
     */
    public static long fSort(int array[])
    {
        int n = array.length;


        for (int gap = n / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < n; i++) {
                int key = array[i];
                int j = i;
                while (j >= gap) {
                    qSortCompares++; // increment for the j >= gap comparison
                    if (array[j - gap] > key) {
                        array[j] = array[j - gap];
                        j -= gap;
                    } else {
                        break;
                    }
                array[j] = key;
            }
        }

    }
        return qSortCompares;
    }

    /**
     * ---------------------------- g Sort ---------------------------------------
     */
    public static long gSort(int array[]) {
        int count = 0;
        int min = array[0];
        int max = array[0];

        for (int i = 1; i < array.length; i++) {
            qSortCompares++;
            if (array[i] < min)
                min = array[i];
            else if (array[i] > max)
                max = array[i];
        }
        int b[] = new int[max - min + 1];
        for (int i = 0; i < array.length; i++)
            b[array[i] - min]++;
        for (int i = 0; i < b.length; i++)
            for (int j = 0; j < b[i]; j++) {
                array[count++] = i + min;
            }
        return qSortCompares;
    }
    /**
     * The non-recursive Quicksort - manages first call
     *
     * @param array an unsorted array that will be sorted upon method completion
     * @return
     */
    public static long aSort(int array[]) {
        qSortCompares = 0;
        return doASort(array, 0, array.length - 1, 0);
    }
    /**
     * The doQuickSort method uses the QuickSort algorithm to sort an int array.
     *
     * @param array The array to sort.
     * @param start The starting subscript of the list to sort
     * @param end The ending subscript of the list to sort
     */
    private static long doASort(int array[], int start, int end, long
            numberOfCompares) {
        int pivotPoint;
        if (start < end) {
// Get the pivot point.
            pivotPoint = part1(array, start, end);
// Note - only one +/=
            numberOfCompares += (end - start);
// Sort the first sub list.
            numberOfCompares = doASort(array, start, pivotPoint - 1,
                    numberOfCompares);
// Sort the second sub list.
            numberOfCompares = doASort(array, pivotPoint + 1, end,
                    numberOfCompares);
        }
        return numberOfCompares;
    }
    /**
     * The partition method selects a pivot value in an array and arranges the
     * array into two sub lists. All the values less than the pivot will be
     * stored in the left sub list and all the values greater than or equal to
     * the pivot will be stored in the right sub list.
     *
     * @param array The array to partition.
     * @param start The starting subscript of the area to partition.
     * @param end The ending subscript of the area to partition.
     * @return The subscript of the pivot value.
     */
    private static int part1(int array[], int start, int end) {
        int pivotValue; // To hold the pivot value
        int endOfLeftList; // Last element in the left sub list.
        int mid; // To hold the mid-point subscript
// see http://www.cs.cmu.edu/~fp/courses/15122-s11/lectures/08-qsort.pdf
// for discussion of middle point - This improves the almost sorted cases
// of using quicksort
// Find the subscript of the middle element.
// This will be our pivot value.
        mid = (start + end) / 2;
// mid = start;
// Swap the middle element with the first element.
// This moves the pivot value to the start of
// the list.
        swap(array, start, mid);
// Save the pivot value for comparisons.
        pivotValue = array[start];
// For now, the end of the left sub list is
// the first element.
        endOfLeftList = start;
// Scan the entire list and move any values that
// are less than the pivot value to the left
// sub list.
        for (int scan = start + 1; scan <= end; scan++) {
            qSortCompares++;
            if (array[scan] < pivotValue) {
                endOfLeftList++;
                swap(array, endOfLeftList, scan);
            }
        }
// Move the pivot value to end of the
// left sub list.
        swap(array, start, endOfLeftList);
// Return the subscript of the pivot value.
        return endOfLeftList;
    }
    public static long dSort(int inputArray[]) {
        int length = inputArray.length;
// Create array only once for merging
        int[] workingArray = new int[inputArray.length];
        long count = 0;
        count = doDSort(inputArray, workingArray, 0, length - 1, count);
        return count;
    }
    private static long doDSort(int[] inputArray, int[] workingArray, int
            lowerIndex, int higherIndex, long count) {
        if (lowerIndex < higherIndex) {
            int middle = lowerIndex + (higherIndex - lowerIndex) / 2;
// Below step sorts the left side of the array
            doDSort(inputArray, workingArray, lowerIndex, middle, count);
// Below step sorts the right side of the array
            doDSort(inputArray, workingArray, middle + 1, higherIndex, count);
// Now merge both sides
            part2(inputArray, workingArray, lowerIndex, middle, higherIndex);
        }
        return count;
    }
    private static long part2(int[] inputArray, int[] workingArray, int lowerIndex,
                              int middle, int higherIndex) {
        long count = 0;
        for (int i = lowerIndex; i <= higherIndex; i++) {
            workingArray[i] = inputArray[i];
        }
        int i1 = lowerIndex;
        int i2 = middle + 1;
        int newIndex = lowerIndex;
        while (i1 <= middle && i2 <= higherIndex) {
            if (workingArray[i1] <= workingArray[i2]) {
                inputArray[newIndex] = workingArray[i1];
                i1++;
            } else {
                inputArray[newIndex] = workingArray[i2];
                i2++;
            }
            newIndex++;
        }
        while (i1 <= middle) {
            inputArray[newIndex] = workingArray[i1];
            newIndex++;
            i1++;
        }
        return count;
    }
    /**
     * The main method will run through all of the Sorts for the prescribed sizes
     and produce output for parts A and B
     *
     * Part C should be answered at the VERY TOP of the code in a comment
     * *
     */
    public static void main(String[] args) {
        System.out.println("--------Part one Table----------");
        int[] dataSet20= generateRandomArray(20);
        int[] dataSet100= generateRandomArray(100);
        int[] dataSet10000= generateRandomArray(10000);
        int[] dataSet50000= generateRandomArray(50000);

        String[] algorithmName = {"eSort","cSort", "bSort","fSort","gSort", "aSort"};
        System.out.println("---------------------------------------------------------");
        System.out.println("| Sorting Algorithm  | Data Size | Avg Time (Microseconds) | Number Of Comparisons |Time per Basic Step (Nanoseconds) |");
        performSort(algorithmName[0], dataSet20);
        performSort(algorithmName[1], dataSet100);
        performSort(algorithmName[2], dataSet10000);
        performSort(algorithmName[3], dataSet50000);
        performSort(algorithmName[4], dataSet20);
        performSort(algorithmName[5], dataSet100);
        System.out.println("--------Part 2 Searches Compare----------");
        compareSearches();

    }



    public static void performSort(String algorithmName, int[] originalData) {
        int[] data = Arrays.copyOf(originalData, originalData.length);
        long totalExecutionTime = 0;
        long comparisons = 0;
        long totalComparisons = 0;
        final int RUNS = 5;


        for (int i = 0; i < RUNS; i++) {
            long startTime = System.nanoTime();

            // Sort the data using the specified algorithm and count comparisons.
            switch (algorithmName) {
                case "eSort":
                    comparisons = eSort(data);

                    break;
                case "cSort":
                    comparisons = cSort(data);
                    break;
                case "bSort":
                    comparisons = bSort(data);
                    break;
                case "fSort":
                    comparisons = fSort(data);
                    break;
                case "gSort":
                    comparisons = gSort(data);
                    break;
                case "aSort":
                    comparisons = aSort(data);
                    break;
                case "dSort":
                    comparisons = dSort(data);
                    break;
            }
            long endTime = System.nanoTime();



            totalExecutionTime += (endTime - startTime);
            totalComparisons += comparisons;
        }

        long averagedExecutionTimeMicroseconds = totalExecutionTime / (RUNS * 1000); // Convert to microseconds
        long averagedComparisons = totalComparisons / (RUNS * 1000);
        long timePerBasicStepNanoseconds = 0;


        if (averagedComparisons != 0) {
            timePerBasicStepNanoseconds = averagedExecutionTimeMicroseconds * 1000 / averagedComparisons;
        }
        // Print the results in a tabular format.

        System.out.println("---------------------------------------------------------");
        System.out.printf("| %-17s | %-9d | %-24d | %-15d | %-36d |\n",
                algorithmName, data.length, averagedExecutionTimeMicroseconds, averagedComparisons, timePerBasicStepNanoseconds);
        System.out.println("---------------------------------------------------------");

        }

    public static int[] generateRandomArray(int size) {
        int[] randomArray = new int[size];
        for (int i = 0; i < size; i++) {
            randomArray[i] = (int) (Math.random() * 51000);
        }
        return randomArray;
    }


    /**
     * A demonstration of recursive counting in a Binary Search
     * @param array - array to search
     * @param low - the low index - set to 0 to search whiole array
     * @param high - set to length of array to search whole array
     * @param value - item to search for
     * @param count - Used in recursion to accumulate the number of comparisons
    made (set to 0 on initial call)
     * @return
     */
    private static int[] binarySearchR(int[] array, int low, int high, int value,
                                       int count)
    {
        int middle; // Mid point of search
// Test for the base case where the value is not found.
        if (low > high)
            return new int[] {-1,count};
// Calculate the middle position.
        middle = (low + high) / 2;
// Search for the value.
        if (array[middle] == value)
// Found match return the index
            return new int[] {middle, count};
        else if (value > array[middle])
// Recursive method call here (Upper half of remaining data)
            return binarySearchR(array, middle + 1, high, value, count+1);
        else
// Recursive method call here (Lower half of remaining data)
            return binarySearchR(array, low, middle - 1, value, count+1);
    }



    /**
     * This method performs a linear search on an array to find a specified value.
     *
     * @param array The array of integers to be searched.
     * @param value The value to search for within the array.
     * @return true if the value is found in the array; false otherwise.
     */
    public static boolean linearSearch(int[] array, int value) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == value) {
                return true;
            }
        }
        return false;
    }
    /**
     * This method compares the performance of linear search and binary search on an array of 100,000 random integers.
     * The goal is to determine the efficiency of each method by measuring the time it takes to search for a value (-1).
     * The value -1 is chosen because it's guaranteed not to be in the array of positive integers.
     * The method also calculates how many linear searches would be needed to justify the time taken by sorting the array followed by a binary search.
     * The results, including the time taken by each search method and the number of linear searches required to justify the sort + binary search, are printed to the console.
     */
    public static void compareSearches(){
        int[] array = generateRandomArray(100000);

        // Linear Search
        long startTimeA = System.nanoTime();
        linearSearch(array, -1);
        long endTimeA = System.nanoTime();

        // Sort and then Binary Search
        // For this example, I'm using Java's built-in sort. Replace with your sorting method if needed.
        Arrays.sort(array);
        long startTimeB = System.nanoTime();
        binarySearchR(array, 0, array.length - 1, -1, 0);
        long endTimeB = System.nanoTime();

        double linearTime = (double) (endTimeA - startTimeA) / 1_000_000; // in milliseconds
        double sortBinaryTime = (double) (endTimeB - startTimeB) / 1_000_000; // in milliseconds

        System.out.println("Time for Linear Search: " + linearTime + " milliseconds");
        System.out.println("Time for Sort/Binary Search: " + sortBinaryTime + " milliseconds");

        // Calculating how many linear searches justify the sort + binary search
        double numSearches = sortBinaryTime / linearTime;
        System.out.println("Number of linear searches required to justify sorting: " + numSearches);
    }


    }



